class PollutionReport {
  final String id;
  final String title;
  final String description;
  final PollutionType type;
  final double latitude;
  final double longitude;
  final String address;
  final List<String> imageUrls;
  final String userId;
  final DateTime reportDate;
  final ReportStatus status;
  final int severity;

  PollutionReport({
    required this.id,
    required this.title,
    required this.description,
    required this.type,
    required this.latitude,
    required this.longitude,
    required this.address,
    this.imageUrls = const [],
    required this.userId,
    required this.reportDate,
    this.status = ReportStatus.pending,
    this.severity = 1,
  });


  factory PollutionReport.fromJson(Map<String, dynamic> json) {
    return PollutionReport(
      id: json['id'],
      title: json['title'],
      description: json['description'],
      type: PollutionType.values.firstWhere(
            (e) => e.toString() == 'PollutionType.${json['type']}',
        orElse: () => PollutionType.other,
      ),
      latitude: json['latitude'],
      longitude: json['longitude'],
      address: json['address'],
      imageUrls: List<String>.from(json['imageUrls']),
      userId: json['userId'],
      reportDate: DateTime.parse(json['reportDate']),
      status: ReportStatus.values.firstWhere(
            (e) => e.toString() == 'ReportStatus.${json['status']}',
        orElse: () => ReportStatus.pending,
      ),
      severity: json['severity'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'type': type.toString().split('.').last,
      'latitude': latitude,
      'longitude': longitude,
      'address': address,
      'imageUrls': imageUrls,
      'userId': userId,
      'reportDate': reportDate.toIso8601String(),
      'status': status.toString().split('.').last,
      'severity': severity,
    };
  }
}

enum PollutionType {
  air,
  water,
  soil,
  noise,
  waste,
  deforestation,
  industrial,
  chemical,
  plastic,
  other
}

enum ReportStatus {
  pending,
  underReview,
  resolved,
  rejected
}