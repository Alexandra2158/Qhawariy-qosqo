// ELIMINA completamente la propiedad aqiColor del modelo
// Solo deja el mé

class AirQuality {
  final double latitude;
  final double longitude;
  final int aqi; // Air Quality Index
  final Map<String, double> pollutants;
  final DateTime timestamp;

  AirQuality({
    required this.latitude,
    required this.longitude,
    required this.aqi,
    required this.pollutants,
    required this.timestamp,
  });

  String get aqiDescription {
    switch (aqi) {
      case 1: return 'Buena';
      case 2: return 'Moderada';
      case 3: return 'Regular';
      case 4: return 'Mala';
      case 5: return 'Muy Mala';
      default: return 'Desconocida';
    }
  }
}