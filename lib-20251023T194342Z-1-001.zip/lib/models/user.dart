class User {
  final String id;
  final String name;
  final String email;
  final String? phone;
  final String? avatarUrl;
  final DateTime joinDate;
  final int reportsCount;
  final double reputation;

  User({
    required this.id,
    required this.name,
    required this.email,
    this.phone,
    this.avatarUrl,
    required this.joinDate,
    this.reportsCount = 0,
    this.reputation = 0.0,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'],
      name: json['name'],
      email: json['email'],
      phone: json['phone'],
      avatarUrl: json['avatarUrl'],
      joinDate: DateTime.parse(json['joinDate']),
      reportsCount: json['reportsCount'] ?? 0,
      reputation: (json['reputation'] ?? 0).toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'phone': phone,
      'avatarUrl': avatarUrl,
      'joinDate': joinDate.toIso8601String(),
      'reportsCount': reportsCount,
      'reputation': reputation,
    };
  }
}