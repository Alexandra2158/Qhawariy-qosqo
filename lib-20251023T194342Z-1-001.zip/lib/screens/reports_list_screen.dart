import 'package:flutter/material.dart';
import '../models/pollution_report.dart';
import '../services/pollution_service.dart';
import '../widgets/report_card.dart';

class ReportsListScreen extends StatefulWidget {
  @override
  _ReportsListScreenState createState() => _ReportsListScreenState();
}

class _ReportsListScreenState extends State<ReportsListScreen> {
  List<PollutionReport> _reports = [];
  bool _loading = true;
  String _error = '';
  PollutionType? _selectedFilter;

  @override
  void initState() {
    super.initState();
    _loadReports();
  }

  Future<void> _loadReports() async {
    setState(() {
      _loading = true;
      _error = '';
    });

    try {
      final reports = await PollutionService.getReports();
      setState(() {
        _reports = reports;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  List<PollutionReport> get _filteredReports {
    if (_selectedFilter == null) return _reports;
    return _reports.where((report) => report.type == _selectedFilter).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Reportes de Contaminación'),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: _loadReports,
          ),
        ],
      ),
      body: Column(
        children: [
          // Filtros
          Container(
            height: 60,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: EdgeInsets.symmetric(horizontal: 16),
              children: [
                _buildFilterChip(null, 'Todos'),
                ...PollutionType.values.map((type) => _buildFilterChip(type, _getTypeName(type))),
              ],
            ),
          ),
          Divider(),

          // Lista de reportes
          Expanded(
            child: _loading
                ? Center(child: CircularProgressIndicator())
                : _error.isNotEmpty
                ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('Error: $_error'),
                  SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: _loadReports,
                    child: Text('Reintentar'),
                  ),
                ],
              ),
            )
                : _filteredReports.isEmpty
                ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.report_problem, size: 64, color: Colors.grey),
                  SizedBox(height: 16),
                  Text(
                    'No hay reportes',
                    style: TextStyle(fontSize: 18),
                  ),
                  SizedBox(height: 8),
                  Text(
                    _selectedFilter == null
                        ? 'No se encontraron reportes'
                        : 'No hay reportes de ${_getTypeName(_selectedFilter!)}',
                    style: TextStyle(color: Colors.grey),
                  ),
                ],
              ),
            )
                : RefreshIndicator(
              onRefresh: _loadReports,
              child: ListView.builder(
                itemCount: _filteredReports.length,
                itemBuilder: (context, index) {
                  final report = _filteredReports[index];
                  return ReportCard(report: report);
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip(PollutionType? type, String label) {
    return Padding(
      padding: const EdgeInsets.only(right: 8.0),
      child: FilterChip(
        label: Text(label),
        selected: _selectedFilter == type,
        onSelected: (selected) {
          setState(() {
            _selectedFilter = selected ? type : null;
          });
        },
      ),
    );
  }

  String _getTypeName(PollutionType type) {
    switch (type) {
      case PollutionType.air: return 'Aire';
      case PollutionType.water: return 'Agua';
      case PollutionType.soil: return 'Suelo';
      case PollutionType.noise: return 'Ruido';
      case PollutionType.waste: return 'Residuos';
      case PollutionType.deforestation: return 'Deforestación';
      case PollutionType.industrial: return 'Industrial';
      case PollutionType.chemical: return 'Químico';
      case PollutionType.plastic: return 'Plástico';
      case PollutionType.other: return 'Otro';
      default: return 'Desconocido';
    }
  }
}