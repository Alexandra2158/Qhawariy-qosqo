import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../models/pollution_report.dart';
import '../services/pollution_service.dart';

class MapScreen extends StatefulWidget {
  @override
  _MapScreenState createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  GoogleMapController? _mapController;
  final LatLng _initialPosition = LatLng(-13.5160, -71.9788); // Cusco center
  final Set<Marker> _markers = {};
  List<PollutionReport> _reports = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadReports();
  }

  Future<void> _loadReports() async {
    try {
      final reports = await PollutionService.getReports();
      setState(() {
        _reports = reports;
        _addMarkers();
        _loading = false;
      });
    } catch (e) {
      print('Error loading reports for map: $e');
      setState(() {
        _loading = false;
      });
    }
  }

  void _addMarkers() {
    _markers.clear();

    for (final report in _reports) {
      final marker = Marker(
        markerId: MarkerId(report.id),
        position: LatLng(report.latitude, report.longitude),
        infoWindow: InfoWindow(
          title: report.title,
          snippet: 'Tipo: ${_getTypeName(report.type)}',
        ),
        icon: BitmapDescriptor.defaultMarkerWithHue(_getMarkerHue(report.type)),
      );

      _markers.add(marker);
    }

    // Agregar marcador central de Cusco
    _markers.add(
      Marker(
        markerId: MarkerId('cusco_center'),
        position: _initialPosition,
        infoWindow: InfoWindow(title: 'Cusco - Centro'),
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
      ),
    );
  }

  double _getMarkerHue(PollutionType type) {
    switch (type) {
      case PollutionType.air: return BitmapDescriptor.hueRed;
      case PollutionType.water: return BitmapDescriptor.hueBlue;
      case PollutionType.soil: return BitmapDescriptor.hueOrange;
      case PollutionType.noise: return BitmapDescriptor.hueViolet;
      case PollutionType.waste: return BitmapDescriptor.hueRose;
      case PollutionType.deforestation: return BitmapDescriptor.hueGreen;
      case PollutionType.industrial: return BitmapDescriptor.hueYellow;
      case PollutionType.chemical: return BitmapDescriptor.hueCyan;
      case PollutionType.plastic: return BitmapDescriptor.hueMagenta;
      case PollutionType.other: return BitmapDescriptor.hueAzure;
      default: return BitmapDescriptor.hueRed;
    }
  }

  String _getTypeName(PollutionType type) {
    switch (type) {
      case PollutionType.air: return 'Contaminación del Aire';
      case PollutionType.water: return 'Contaminación del Agua';
      case PollutionType.soil: return 'Contaminación del Suelo';
      case PollutionType.noise: return 'Contaminación Acústica';
      case PollutionType.waste: return 'Manejo de Residuos';
      case PollutionType.deforestation: return 'Deforestación';
      case PollutionType.industrial: return 'Contaminación Industrial';
      case PollutionType.chemical: return 'Contaminación Química';
      case PollutionType.plastic: return 'Contaminación por Plástico';
      case PollutionType.other: return 'Otro Tipo';
      default: return 'Desconocido';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Mapa de Reportes - Cusco'),
        backgroundColor: Colors.green,
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: _loadReports,
          ),
        ],
      ),
      body: _loading
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('Cargando mapa...'),
          ],
        ),
      )
          : GoogleMap(
        onMapCreated: (controller) {
          setState(() {
            _mapController = controller;
          });
        },
        initialCameraPosition: CameraPosition(
          target: _initialPosition,
          zoom: 12,
        ),
        markers: _markers,
        myLocationEnabled: true,
        myLocationButtonEnabled: true,
        compassEnabled: true,
        zoomControlsEnabled: true,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _mapController?.animateCamera(
            CameraUpdate.newLatLng(_initialPosition),
          );
        },
        child: Icon(Icons.center_focus_strong),
        backgroundColor: Colors.green,
      ),
    );
  }
}