import 'package:flutter/material.dart';
import '../models/pollution_report.dart';

class ReportDetailScreen extends StatelessWidget {
  final PollutionReport report;

  const ReportDetailScreen({Key? key, required this.report}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detalle del Reporte'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header con tipo y estado
            Row(
              children: [
                _buildTypeChip(report.type),
                Spacer(),
                _buildStatusChip(report.status),
              ],
            ),
            SizedBox(height: 20),

            // Título
            Text(
              report.title,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 16),

            // Descripción
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Descripción',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(report.description),
                  ],
                ),
              ),
            ),
            SizedBox(height: 16),

            // Información de ubicación
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Ubicación',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    SizedBox(height: 8),
                    Row(
                      children: [
                        Icon(Icons.location_on, color: Colors.red),
                        SizedBox(width: 8),
                        Expanded(child: Text(report.address)),
                      ],
                    ),
                    SizedBox(height: 8),
                    Text('Coordenadas: ${report.latitude.toStringAsFixed(4)}, ${report.longitude.toStringAsFixed(4)}'),
                  ],
                ),
              ),
            ),
            SizedBox(height: 16),

            // Información adicional
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Información Adicional',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    SizedBox(height: 12),
                    _buildInfoRow('Severidad', '${report.severity}/5'),
                    _buildInfoRow('Fecha', _formatDate(report.reportDate)),
                    _buildInfoRow('ID del Reporte', report.id),
                  ],
                ),
              ),
            ),
            SizedBox(height: 16),

            // Imágenes (si existen)
            if (report.imageUrls.isNotEmpty) ...[
              Text(
                'Evidencia Fotográfica',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
              SizedBox(height: 8),
              Container(
                height: 200,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: report.imageUrls.length,
                  itemBuilder: (context, index) {
                    return Container(
                      width: 200,
                      margin: EdgeInsets.only(right: 8),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        image: DecorationImage(
                          image: NetworkImage(report.imageUrls[index]),
                          fit: BoxFit.cover,
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildTypeChip(PollutionType type) {
    return Chip(
      label: Text(
        _getTypeName(type),
        style: TextStyle(color: Colors.white),
      ),
      backgroundColor: _getTypeColor(type),
    );
  }

  Widget _buildStatusChip(ReportStatus status) {
    Color color;
    switch (status) {
      case ReportStatus.pending:
        color = Colors.orange;
        break;
      case ReportStatus.underReview:
        color = Colors.blue;
        break;
      case ReportStatus.resolved:
        color = Colors.green;
        break;
      case ReportStatus.rejected:
        color = Colors.red;
        break;
    }

    return Chip(
      label: Text(
        _getStatusName(status),
        style: TextStyle(color: Colors.white),
      ),
      backgroundColor: color,
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        children: [
          Text(
            '$label: ',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          Text(value),
        ],
      ),
    );
  }

  String _getTypeName(PollutionType type) {
    switch (type) {
      case PollutionType.air: return 'Contaminación del Aire';
      case PollutionType.water: return 'Contaminación del Agua';
      case PollutionType.soil: return 'Contaminación del Suelo';
      case PollutionType.noise: return 'Contaminación Acústica';
      case PollutionType.waste: return 'Manejo de Residuos';
      case PollutionType.deforestation: return 'Deforestación';
      case PollutionType.industrial: return 'Contaminación Industrial';
      case PollutionType.chemical: return 'Contaminación Química';
      case PollutionType.plastic: return 'Contaminación por Plástico';
      case PollutionType.other: return 'Otro Tipo';
      default: return 'Desconocido';
    }
  }

  Color _getTypeColor(PollutionType type) {
    switch (type) {
      case PollutionType.air: return Colors.blue;
      case PollutionType.water: return Colors.cyan;
      case PollutionType.soil: return Colors.brown;
      case PollutionType.noise: return Colors.purple;
      case PollutionType.waste: return Colors.orange;
      case PollutionType.deforestation: return Colors.green;
      case PollutionType.industrial: return Colors.grey;
      case PollutionType.chemical: return Colors.red;
      case PollutionType.plastic: return Colors.pink;
      case PollutionType.other: return Colors.grey;
      default: return Colors.grey;
    }
  }

  String _getStatusName(ReportStatus status) {
    switch (status) {
      case ReportStatus.pending: return 'Pendiente';
      case ReportStatus.underReview: return 'En Revisión';
      case ReportStatus.resolved: return 'Resuelto';
      case ReportStatus.rejected: return 'Rechazado';
      default: return 'Desconocido';
    }
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year} ${date.hour}:${date.minute.toString().padLeft(2, '0')}';
  }
}