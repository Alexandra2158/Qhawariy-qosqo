import 'package:flutter/material.dart';
import '../models/pollution_report.dart';
import '../services/pollution_service.dart';
import '../widgets/pollution_type_selector.dart';
import '../widgets/location_picker.dart';
import '../widgets/image_picker.dart';

class ReportScreen extends StatefulWidget {
  @override
  _ReportScreenState createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();

  PollutionType _selectedType = PollutionType.air;
  double? _latitude;
  double? _longitude;
  String _address = '';
  List<String> _imageUrls = [];
  int _severity = 1;
  bool _isSubmitting = false;

  Future<void> _submitReport() async {
    if (!_formKey.currentState!.validate()) return;
    if (_latitude == null || _longitude == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Por favor selecciona una ubicación')),
      );
      return;
    }

    setState(() => _isSubmitting = true);

    try {
      final report = PollutionReport(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        title: _titleController.text,
        description: _descriptionController.text,
        type: _selectedType,
        latitude: _latitude!,
        longitude: _longitude!,
        address: _address,
        imageUrls: _imageUrls,
        userId: 'current_user_id', // Reemplaza con ID de usuario real
        reportDate: DateTime.now(),
        severity: _severity,
      );

      await PollutionService.submitReport(report);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Reporte enviado exitosamente')),
      );

      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error al enviar reporte: $e')),
      );
    } finally {
      setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Nuevo Reporte'),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              PollutionTypeSelector(
                selectedType: _selectedType,
                onTypeChanged: (type) => setState(() => _selectedType = type),
              ),
              SizedBox(height: 20),
              TextFormField(
                controller: _titleController,
                decoration: InputDecoration(
                  labelText: 'Título del reporte',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor ingresa un título';
                  }
                  return null;
                },
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _descriptionController,
                decoration: InputDecoration(
                  labelText: 'Descripción detallada',
                  border: OutlineInputBorder(),
                  alignLabelWithHint: true,
                ),
                maxLines: 4,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor ingresa una descripción';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              LocationPicker(
                onLocationSelected: (lat, lng, address) {
                  setState(() {
                    _latitude = lat;
                    _longitude = lng;
                    _address = address;
                  });
                },
              ),
              SizedBox(height: 20),
              Text('Severidad: $_severity'),
              Slider(
                value: _severity.toDouble(),
                min: 1,
                max: 5,
                divisions: 4,
                onChanged: (value) => setState(() => _severity = value.toInt()),
              ),
              SizedBox(height: 20),
              CustomImagePicker(
                onImagesChanged: (images) => setState(() => _imageUrls = images),
              ),
              SizedBox(height: 30),
              ElevatedButton(
                onPressed: _isSubmitting ? null : _submitReport,
                child: _isSubmitting
                    ? CircularProgressIndicator()
                    : Text('Enviar Reporte'),
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}