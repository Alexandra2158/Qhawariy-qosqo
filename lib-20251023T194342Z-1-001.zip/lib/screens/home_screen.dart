import 'package:flutter/material.dart';
import '../widgets/custom_app_bar.dart';
import '../widgets/air_quality_indicator.dart';
import 'report_screen.dart';
import 'reports_list_screen.dart';
import 'air_quality_screen.dart';
import 'map_screen.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(title: 'EcoReport'),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Bienvenido',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            SizedBox(height: 8),
            Text(
              'Reporta casos de contaminación en tu comunidad',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            SizedBox(height: 24),

            // Indicador de calidad del aire
            AirQualityIndicator(),
            SizedBox(height: 24),

            // Grid de acciones rápidas
            GridView.count(
              shrinkWrap: true,
              crossAxisCount: 2,
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
              children: [
                _buildActionCard(
                  context,
                  'Nuevo Reporte',
                  Icons.add_circle,
                  Colors.green,
                      () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ReportScreen()),
                  ),
                ),
                _buildActionCard(
                  context,
                  'Ver Reportes',
                  Icons.list_alt,
                  Colors.blue,
                      () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ReportsListScreen()),
                  ),
                ),
                _buildActionCard(
                  context,
                  'Mapa',
                  Icons.map,
                  Colors.orange,
                      () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => MapScreen()),
                  ),
                ),
                _buildActionCard(
                  context,
                  'Calidad del Aire',
                  Icons.air,
                  Colors.purple,
                      () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => AirQualityScreen()),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionCard(BuildContext context, String title, IconData icon, Color color, VoidCallback onTap) {
    return Card(
      elevation: 4,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 40, color: color),
            SizedBox(height: 8),
            Text(
              title,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleMedium,
            ),
          ],
        ),
      ),
    );
  }
}