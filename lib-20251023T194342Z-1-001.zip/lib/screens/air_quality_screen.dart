import 'package:flutter/material.dart';
import '../services/air_quality_service.dart'; // Asegúrate de importar el servicio
import '../services/location_service.dart';
import '../models/air_quality.dart';

class AirQualityScreen extends StatefulWidget {
  @override
  _AirQualityScreenState createState() => _AirQualityScreenState();
}

class _AirQualityScreenState extends State<AirQualityScreen> {
  AirQuality? _airQuality;
  bool _loading = false;
  String _error = '';

  Future<void> _getCurrentAirQuality() async {
    setState(() {
      _loading = true;
      _error = '';
    });

    try {
      final position = await LocationService.getCurrentLocation();
      final airQuality = await AirQualityService.getAirQuality(
        position.latitude,
        position.longitude,
      );

      setState(() {
        _airQuality = airQuality;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Calidad del Aire'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    Icon(Icons.air, size: 64, color: Colors.blue),
                    SizedBox(height: 16),
                    Text(
                      'Calidad del Aire en Tiempo Real',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Obtén información actualizada sobre la calidad del aire en tu ubicación',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey[600]),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: _getCurrentAirQuality,
              icon: Icon(Icons.refresh),
              label: Text('Obtener Calidad del Aire Actual'),
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 16),
              ),
            ),
            SizedBox(height: 20),
            if (_loading) ...[
              Center(child: CircularProgressIndicator()),
              SizedBox(height: 16),
              Text(
                'Obteniendo datos de calidad del aire...',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey[600]),
              ),
            ],
            if (_error.isNotEmpty) ...[
              Card(
                color: Colors.red[50],
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      Icon(Icons.error, color: Colors.red, size: 48),
                      SizedBox(height: 8),
                      Text(
                        'Error',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.red,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        _error,
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.red[700]),
                      ),
                    ],
                  ),
                ),
              ),
            ],
            if (_airQuality != null) _buildAirQualityInfo(),
          ],
        ),
      ),
    );
  }

  Widget _buildAirQualityInfo() {
    final airQuality = _airQuality!;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 20,
                  height: 20,
                  decoration: BoxDecoration(
                    // USA el método del servicio
                    color: AirQualityService.getAirQualityColor(airQuality.aqi),
                    shape: BoxShape.circle,
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Calidad del Aire: ${airQuality.aqiDescription}',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),
            Text(
              'Contaminantes Principales',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
            SizedBox(height: 12),
            _buildPollutantRow('PM2.5', '${airQuality.pollutants['pm2_5']} μg/m³'),
            _buildPollutantRow('PM10', '${airQuality.pollutants['pm10']} μg/m³'),
            _buildPollutantRow('Dióxido de Nitrógeno (NO₂)', '${airQuality.pollutants['no2']} μg/m³'),
            _buildPollutantRow('Ozono (O₃)', '${airQuality.pollutants['o3']} μg/m³'),
            _buildPollutantRow('Dióxido de Azufre (SO₂)', '${airQuality.pollutants['so2']} μg/m³'),
            _buildPollutantRow('Monóxido de Carbono (CO)', '${airQuality.pollutants['co']} μg/m³'),
            SizedBox(height: 16),
            Text(
              'Última actualización: ${_formatTime(airQuality.timestamp)}',
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPollutantRow(String name, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6.0),
      child: Row(
        children: [
          Expanded(child: Text(name)),
          Text(
            value,
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  String _formatTime(DateTime time) {
    return '${time.hour}:${time.minute.toString().padLeft(2, '0')}';
  }
}