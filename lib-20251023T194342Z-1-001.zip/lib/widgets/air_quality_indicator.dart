import 'package:flutter/material.dart';
import '../services/air_quality_service.dart';

class AirQualityIndicator extends StatelessWidget {
  // Por simplicidad, usamos un valor estático
  // En una app real, obtendrías esto de una API
  final int currentAqi = 2; // Moderado

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.air, color: Colors.blue),
                SizedBox(width: 8),
                Text(
                  'Calidad del Aire Actual',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            SizedBox(height: 12),
            Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: AirQualityService.getAirQualityColor(currentAqi),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      currentAqi.toString(),
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        AirQualityService.getAirQualityDescription(currentAqi),
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        _getAqiMessage(currentAqi),
                        style: TextStyle(
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  String _getAqiMessage(int aqi) {
    switch (aqi) {
      case 1: return 'La calidad del aire es ideal para actividades al aire libre.';
      case 2: return 'La calidad del aire es aceptable.';
      case 3: return 'Grupos sensibles deben considerar reducir actividades al aire libre.';
      case 4: return 'Todos pueden comenzar a experimentar efectos en la salud.';
      case 5: return 'Advertencia de condiciones de emergencia.';
      default: return 'Información no disponible.';
    }
  }
}