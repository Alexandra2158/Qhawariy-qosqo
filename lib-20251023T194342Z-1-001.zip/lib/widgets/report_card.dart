import 'package:flutter/material.dart';
import '../models/pollution_report.dart';

class ReportCard extends StatelessWidget {
  final PollutionReport report;

  const ReportCard({Key? key, required this.report}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: InkWell(
        onTap: () {
          // Navegar a pantalla de detalle
        },
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  _buildTypeChip(report.type),
                  Spacer(),
                  _buildStatusChip(report.status),
                ],
              ),
              SizedBox(height: 12),
              Text(
                report.title,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8),
              Text(
                report.description,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: Colors.grey[600]),
              ),
              SizedBox(height: 12),
              Row(
                children: [
                  Icon(Icons.location_on, size: 16, color: Colors.grey),
                  SizedBox(width: 4),
                  Expanded(
                    child: Text(
                      report.address,
                      style: TextStyle(fontSize: 12, color: Colors.grey),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  SizedBox(width: 16),
                  Icon(Icons.calendar_today, size: 16, color: Colors.grey),
                  SizedBox(width: 4),
                  Text(
                    _formatDate(report.reportDate),
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ],
              ),
              SizedBox(height: 8),
              LinearProgressIndicator(
                value: report.severity / 5,
                backgroundColor: Colors.grey[300],
                valueColor: AlwaysStoppedAnimation<Color>(_getSeverityColor(report.severity)),
              ),
              SizedBox(height: 4),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Severidad',
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  Text(
                    '${report.severity}/5',
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTypeChip(PollutionType type) {
    return Chip(
      label: Text(
        _getTypeName(type),
        style: TextStyle(color: Colors.white, fontSize: 12),
      ),
      backgroundColor: _getTypeColor(type),
      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
      labelPadding: EdgeInsets.symmetric(horizontal: 8),
    );
  }

  Widget _buildStatusChip(ReportStatus status) {
    Color color;
    String text;

    switch (status) {
      case ReportStatus.pending:
        color = Colors.orange;
        text = 'Pendiente';
        break;
      case ReportStatus.underReview:
        color = Colors.blue;
        text = 'En Revisión';
        break;
      case ReportStatus.resolved:
        color = Colors.green;
        text = 'Resuelto';
        break;
      case ReportStatus.rejected:
        color = Colors.red;
        text = 'Rechazado';
        break;
    }

    return Chip(
      label: Text(
        text,
        style: TextStyle(color: Colors.white, fontSize: 12),
      ),
      backgroundColor: color,
      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
      labelPadding: EdgeInsets.symmetric(horizontal: 8),
    );
  }

  String _getTypeName(PollutionType type) {
    switch (type) {
      case PollutionType.air: return 'Aire';
      case PollutionType.water: return 'Agua';
      case PollutionType.soil: return 'Suelo';
      case PollutionType.noise: return 'Ruido';
      case PollutionType.waste: return 'Residuos';
      case PollutionType.deforestation: return 'Deforestación';
      case PollutionType.industrial: return 'Industrial';
      case PollutionType.chemical: return 'Químico';
      case PollutionType.plastic: return 'Plástico';
      case PollutionType.other: return 'Otro';
      default: return 'Desconocido';
    }
  }

  Color _getTypeColor(PollutionType type) {
    switch (type) {
      case PollutionType.air: return Colors.blue;
      case PollutionType.water: return Colors.cyan;
      case PollutionType.soil: return Colors.brown;
      case PollutionType.noise: return Colors.purple;
      case PollutionType.waste: return Colors.orange;
      case PollutionType.deforestation: return Colors.green;
      case PollutionType.industrial: return Colors.grey;
      case PollutionType.chemical: return Colors.red;
      case PollutionType.plastic: return Colors.pink;
      case PollutionType.other: return Colors.grey;
      default: return Colors.grey;
    }
  }

  Color _getSeverityColor(int severity) {
    switch (severity) {
      case 1: return Colors.green;
      case 2: return Colors.lightGreen;
      case 3: return Colors.yellow;
      case 4: return Colors.orange;
      case 5: return Colors.red;
      default: return Colors.grey;
    }
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inDays > 0) {
      return 'Hace ${difference.inDays} días';
    } else if (difference.inHours > 0) {
      return 'Hace ${difference.inHours} horas';
    } else if (difference.inMinutes > 0) {
      return 'Hace ${difference.inMinutes} minutos';
    } else {
      return 'Ahora mismo';
    }
  }
}