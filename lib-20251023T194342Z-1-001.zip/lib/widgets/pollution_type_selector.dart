import 'package:flutter/material.dart';
import '../models/pollution_report.dart';

class PollutionTypeSelector extends StatelessWidget {
  final PollutionType selectedType;
  final ValueChanged<PollutionType> onTypeChanged;

  const PollutionTypeSelector({
    Key? key,
    required this.selectedType,
    required this.onTypeChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Tipo de Contaminación',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: PollutionType.values.map((type) {
            return FilterChip(
              label: Text(_getTypeName(type)),
              selected: selectedType == type,
              onSelected: (selected) {
                if (selected) {
                  onTypeChanged(type);
                }
              },
              backgroundColor: _getTypeColor(type).withOpacity(0.1),
              selectedColor: _getTypeColor(type),
              labelStyle: TextStyle(
                color: selectedType == type ? Colors.white : _getTypeColor(type),
              ),
              checkmarkColor: Colors.white,
            );
          }).toList(),
        ),
      ],
    );
  }

  String _getTypeName(PollutionType type) {
    switch (type) {
      case PollutionType.air: return 'Aire';
      case PollutionType.water: return 'Agua';
      case PollutionType.soil: return 'Suelo';
      case PollutionType.noise: return 'Ruido';
      case PollutionType.waste: return 'Residuos';
      case PollutionType.deforestation: return 'Deforestación';
      case PollutionType.industrial: return 'Industrial';
      case PollutionType.chemical: return 'Químico';
      case PollutionType.plastic: return 'Plástico';
      case PollutionType.other: return 'Otro';
      default: return 'Desconocido';
    }
  }

  Color _getTypeColor(PollutionType type) {
    switch (type) {
      case PollutionType.air: return Colors.blue;
      case PollutionType.water: return Colors.cyan;
      case PollutionType.soil: return Colors.brown;
      case PollutionType.noise: return Colors.purple;
      case PollutionType.waste: return Colors.orange;
      case PollutionType.deforestation: return Colors.green;
      case PollutionType.industrial: return Colors.grey;
      case PollutionType.chemical: return Colors.red;
      case PollutionType.plastic: return Colors.pink;
      case PollutionType.other: return Colors.grey;
      default: return Colors.grey;
    }
  }
}