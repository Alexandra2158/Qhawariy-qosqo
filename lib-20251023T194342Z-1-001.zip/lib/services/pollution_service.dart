import '../models/pollution_report.dart';

class PollutionService {
  // Datos de ejemplo para Cusco
  static List<PollutionReport> _mockReports = [
    PollutionReport(
      id: '1',
      title: 'Quema de basura en Plaza de Armas',
      description: 'Personas quemando basura y plásticos en el centro histórico',
      type: PollutionType.air,
      latitude: -13.5160,
      longitude: -71.9788,
      address: 'Plaza de Armas, Cusco',
      imageUrls: [],
      userId: 'user-001',
      reportDate: DateTime.now().subtract(Duration(hours: 2)),
      status: ReportStatus.pending,
      severity: 3,
    ),
    PollutionReport(
      id: '2',
      title: 'Contaminación del Río Huatanay',
      description: 'Desechos y basura acumulada en las orillas del río',
      type: PollutionType.water,
      latitude: -13.5225,
      longitude: -71.9673,
      address: 'Río Huatanay, Cusco',
      imageUrls: [],
      userId: 'user-002',
      reportDate: DateTime.now().subtract(Duration(days: 1)),
      status: ReportStatus.underReview,
      severity: 4,
    ),
    PollutionReport(
      id: '3',
      title: 'Deforestación en Sacsayhuamán',
      description: 'Tala ilegal de árboles nativos en zona arqueológica',
      type: PollutionType.deforestation,
      latitude: -13.5086,
      longitude: -71.9811,
      address: 'Sacsayhuamán, Cusco',
      imageUrls: [],
      userId: 'user-003',
      reportDate: DateTime.now().subtract(Duration(days: 3)),
      status: ReportStatus.pending,
      severity: 5,
    ),
    PollutionReport(
      id: '4',
      title: 'Ruido excesivo en zona residencial',
      description: 'Bares con música a volumen muy alto durante la madrugada',
      type: PollutionType.noise,
      latitude: -13.5189,
      longitude: -71.9756,
      address: 'Calle Mantas, Cusco',
      imageUrls: [],
      userId: 'user-004',
      reportDate: DateTime.now().subtract(Duration(hours: 5)),
      status: ReportStatus.resolved,
      severity: 2,
    ),
  ];

  static Future<List<PollutionReport>> getReports() async {
    // Simular delay de red
    await Future.delayed(Duration(seconds: 1));
    print('✅ Cargando ${_mockReports.length} reportes de ejemplo');
    return List.from(_mockReports);
  }

  static Future<bool> submitReport(PollutionReport report) async {
    try {
      // Simular delay de red
      await Future.delayed(Duration(seconds: 1));

      // Agregar el nuevo reporte a la lista
      _mockReports.insert(0, report);
      print('✅ Reporte enviado exitosamente: ${report.title}');
      return true;
    } catch (e) {
      print('❌ Error al enviar reporte: $e');
      return false;
    }
  }

  static Future<List<PollutionReport>> getReportsByType(PollutionType type) async {
    await Future.delayed(Duration(seconds: 1));
    final filteredReports = _mockReports.where((report) => report.type == type).toList();
    print('✅ Cargando ${filteredReports.length} reportes de tipo: $type');
    return filteredReports;
  }

  static Future<List<PollutionReport>> searchReports(String query) async {
    await Future.delayed(Duration(milliseconds: 500));
    final results = _mockReports.where((report) =>
    report.title.toLowerCase().contains(query.toLowerCase()) ||
        report.description.toLowerCase().contains(query.toLowerCase()) ||
        report.address.toLowerCase().contains(query.toLowerCase())
    ).toList();
    return results;
  }
}