import 'package:flutter/material.dart'; // AÑADE ESTA LÍNEA
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/air_quality.dart';

class AirQualityService {
  // Usando OpenWeatherMap Air Pollution API
  static const String apiKey = '811e5fdd7222673553763cbe2c139954';
  static const String baseUrl = 'http://api.openweathermap.org/data/2.5/air_pollution';

  static Future<AirQuality> getAirQuality(double lat, double lon) async {
    try {
      final url = Uri.parse('$baseUrl?lat=$lat&lon=$lon&appid=$apiKey');
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return _parseAirQualityData(data, lat, lon);
      } else {
        // Datos de prueba si la API falla
        return AirQuality(
          latitude: lat,
          longitude: lon,
          aqi: 2, // Moderado
          pollutants: {
            'co': 250.0,
            'no2': 20.0,
            'o3': 60.0,
            'so2': 5.0,
            'pm2_5': 15.0,
            'pm10': 25.0,
          },
          timestamp: DateTime.now(),
        );
      }
    } catch (e) {
      // Datos de prueba si hay error de conexión
      return AirQuality(
        latitude: lat,
        longitude: lon,
        aqi: 2,
        pollutants: {
          'co': 250.0,
          'no2': 20.0,
          'o3': 60.0,
          'so2': 5.0,
          'pm2_5': 15.0,
          'pm10': 25.0,
        },
        timestamp: DateTime.now(),
      );
    }
  }

  static AirQuality _parseAirQualityData(Map<String, dynamic> data, double lat, double lon) {
    final main = data['list'][0];
    final components = main['components'];

    return AirQuality(
      latitude: lat,
      longitude: lon,
      aqi: main['main']['aqi'],
      pollutants: {
        'co': components['co'].toDouble(),
        'no2': components['no2'].toDouble(),
        'o3': components['o3'].toDouble(),
        'so2': components['so2'].toDouble(),
        'pm2_5': components['pm2_5'].toDouble(),
        'pm10': components['pm10'].toDouble(),
      },
      timestamp: DateTime.fromMillisecondsSinceEpoch(main['dt'] * 1000),
    );
  }

  static String getAirQualityDescription(int aqi) {
    switch (aqi) {
      case 1: return 'Buena';
      case 2: return 'Moderada';
      case 3: return 'Regular';
      case 4: return 'Mala';
      case 5: return 'Muy Mala';
      default: return 'Desconocida';
    }
  }

  static Color getAirQualityColor(int aqi) {
    switch (aqi) {
      case 1: return Colors.green;
      case 2: return Colors.yellow;
      case 3: return Colors.orange;
      case 4: return Colors.red;
      case 5: return Colors.purple;
      default: return Colors.grey;
    }
  }
}