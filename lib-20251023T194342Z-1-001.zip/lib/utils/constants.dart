import 'package:flutter/material.dart'; // AÑADE ESTA LÍNEA

class AppConstants {
  // URLs de API
  static const String baseApiUrl = 'https://yourapi.com/api';
  static const String airQualityApiUrl = 'http://api.openweathermap.org/data/2.5/air_pollution';

  // Configuración
  static const int maxImageCount = 5;
  static const int maxReportTitleLength = 100;
  static const int maxReportDescriptionLength = 1000;

  // Colores - CORREGIDOS
  static const Map<int, Color> aqiColors = {
    1: Colors.green,
    2: Colors.yellow,
    3: Colors.orange,
    4: Colors.red,
    5: Colors.purple,
  };

  // Mensajes
  static const String appName = 'EcoReport';
  static const String appDescription = 'Reporta y monitorea la contaminación ambiental';
}

class StorageKeys {
  static const String userData = 'user_data';
  static const String appSettings = 'app_settings';
  static const String reportsCache = 'reports_cache';
  static const String airQualityCache = 'air_quality_cache';
}