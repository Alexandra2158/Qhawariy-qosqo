class Validators {
  static String? validateRequired(String? value, String fieldName) {
    if (value == null || value.trim().isEmpty) {
      return 'El campo $fieldName es requerido';
    }
    return null;
  }

  static String? validateEmail(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'El email es requerido';
    }

    final emailRegex = RegExp(
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    );

    if (!emailRegex.hasMatch(value)) {
      return 'Ingresa un email válido';
    }

    return null;
  }

  static String? validatePassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'La contraseña es requerida';
    }

    if (value.length < 6) {
      return 'La contraseña debe tener al menos 6 caracteres';
    }

    return null;
  }

  static String? validatePhone(String? value) {
    if (value == null || value.trim().isEmpty) {
      return null; // El teléfono es opcional
    }

    final phoneRegex = RegExp(r'^[0-9+\-\s()]{10,}$');

    if (!phoneRegex.hasMatch(value)) {
      return 'Ingresa un número de teléfono válido';
    }

    return null;
  }

  static String? validateReportTitle(String? value) {
    final error = validateRequired(value, 'título');
    if (error != null) return error;

    if (value!.length > 100) {
      return 'El título no puede tener más de 100 caracteres';
    }

    return null;
  }

  static String? validateReportDescription(String? value) {
    final error = validateRequired(value, 'descripción');
    if (error != null) return error;

    if (value!.length > 1000) {
      return 'La descripción no puede tener más de 1000 caracteres';
    }

    if (value.length < 10) {
      return 'La descripción debe tener al menos 10 caracteres';
    }

    return null;
  }
}